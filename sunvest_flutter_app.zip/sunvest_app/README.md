# Sunvest Renewables - Flutter WebView App

تطبيق Flutter WebView لموقع Sunvest Renewables

## 📱 الميزات

- ✅ شاشة سبلاش (Splash Screen) احترافية
- ✅ WebView يعرض موقع sunvestrenewables.com
- ✅ شريط علوي مخصص بشعار التطبيق
- ✅ مؤشر تحميل (Progress Bar)
- ✅ التنقل للخلف والأمام
- ✅ كشف انقطاع الإنترنت وإعادة التوصيل
- ✅ معالجة أخطاء التحميل
- ✅ قائمة سفلية (Bottom Sheet) للتنقل
- ✅ يدعم Android و iOS

## 🚀 طريقة التشغيل

### المتطلبات
- Flutter SDK 3.0+
- Android Studio أو Xcode
- Android API 21+ أو iOS 12+

### خطوات الإعداد

1. **تثبيت المتطلبات:**
```bash
flutter pub get
```

2. **تشغيل على Android:**
```bash
flutter run
```

3. **تشغيل على iOS:**
```bash
cd ios && pod install && cd ..
flutter run
```

4. **بناء APK للأندرويد:**
```bash
flutter build apk --release
```
الملف في: `build/app/outputs/flutter-apk/app-release.apk`

5. **بناء IPA للـ iOS:**
```bash
flutter build ipa --release
```

## 📂 هيكل المشروع

```
lib/
  main.dart          # الملف الرئيسي (SplashScreen + WebViewScreen)
android/
  app/
    src/main/
      AndroidManifest.xml   # صلاحيات الإنترنت والإعدادات
pubspec.yaml         # المكتبات المستخدمة
```

## 📦 المكتبات المستخدمة

| المكتبة | الوظيفة |
|---------|---------|
| `webview_flutter` | عرض الموقع داخل التطبيق |
| `connectivity_plus` | مراقبة الاتصال بالإنترنت |
| `url_launcher` | فتح روابط خارجية |

## 🎨 الألوان المستخدمة

- الأخضر الداكن: `#0D2B23` (خلفية)
- الأخضر: `#1A3C34` (شريط العنوان)
- الذهبي/البرتقالي: `#F5A623` (اللون الأساسي)

## ⚙️ تعديل الإعدادات

لتغيير الموقع، افتح `lib/main.dart` وابحث عن:
```dart
_controller.loadRequest(Uri.parse('https://www.sunvestrenewables.com'));
```

لتغيير اسم التطبيق، عدّل `pubspec.yaml`:
```yaml
name: sunvest_renewables
```

وعدّل `android/app/build.gradle`:
```groovy
applicationId "com.sunvest.renewables"
```
